package trello

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class AuthenticationTokenSpec extends Specification implements DomainUnitTest<AuthenticationToken> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
