package trello

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ColumnSpec extends Specification implements DomainUnitTest<Column> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
