package trello

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class CardControllerSpec extends Specification implements ControllerUnitTest<CardController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
        true == false
    }
}