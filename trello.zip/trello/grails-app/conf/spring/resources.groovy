// Place your Spring DSL code here
import trello.UserPasswordEncoderListener
beans = {

userPasswordEncoderListener(UserPasswordEncoderListener)

}
